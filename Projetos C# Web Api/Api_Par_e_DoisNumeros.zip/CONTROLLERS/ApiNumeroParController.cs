﻿using Microsoft.AspNetCore.Mvc;

namespace $safeprojectname$.Controllers
{
    public class ApiNumeroParController : Controller
    {
        [HttpGet("NumeroPar")]
        public string NumeroPar(double numeroUsuario)
        {
            double numero;
            numero = (double)numeroUsuario;

            if (numero % 2 ==0)
            {

                return $"O número: {numero} é par! ";

            }
            return null;
        }



    }
}
