﻿using Microsoft.AspNetCore.Mvc;

namespace $safeprojectname$.Controllers
{
    public class ImpostoController : Controller
    {
        [HttpGet("Imposto")]
        public string Imposto(double salario)
        {
            double valorImposto;

            if (salario <= 1200)
            {
                valorImposto = 0;
                return ($"O salário é: {salario} e o imposto a ser pago é: {valorImposto}");
            }

            else if (salario >= 1201 && salario <= 2500)
            {
                valorImposto = 1201 * (5.0 / 100);
                return ($"O salário é: {salario} e o imposto a ser pago é: {valorImposto}");
            }

            else if (2501 <= salario && salario <= 4000)
            {
                valorImposto = 2501 * (8.0 / 100);
                return ($"O salário é: {salario} e o imposto a ser pago é: {valorImposto}");
            }

            else if (4001 <= salario && salario <= 7000)
            {
                valorImposto = 4001 * (12.0 / 100);
                return ($"O salário é: {salario} e o imposto a ser pago é: {valorImposto}");
            }

            else if (7001 <= salario)
            {
                valorImposto = 7001 * (27.5 / 100);
                return ($"O salário é: {salario} e o imposto a ser pago é: {valorImposto}");
            }
            return null;
        }
    }
}
