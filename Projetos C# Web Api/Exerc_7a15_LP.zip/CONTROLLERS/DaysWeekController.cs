﻿using Microsoft.AspNetCore.Mvc;

namespace $safeprojectname$.Controllers
{
    public class DaysWeekController : Controller
    {
        [HttpGet("DaysWeek")]
        public string DaysWeek(double numero)
        {
            if (numero == 1)
            {
                return("Esse dia é domingo");
            }
            else if (numero == 2)
            {
                return("Esse dia é segunda");
            }
            else if (numero == 3)
            {
                return("Esse dia é terça");
            }
            else if (numero == 4)
            {
                return("Esse dia é quarta");
            }
            else if (numero == 5)
            {
                return("Esse dia é quinta");
            }
            else if (numero == 6)
            {
                return("Esse dia é sexta");
            }
            else if (numero == 7)
            {
                return("Esse dia é sábado");
            }
            else
                return("Essse dia da semana não existe");
        }
        
    }
}
