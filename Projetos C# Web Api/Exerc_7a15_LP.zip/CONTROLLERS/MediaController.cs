﻿using Microsoft.AspNetCore.Mvc;

namespace $safeprojectname$.Controllers
{
    public class MediaController : Controller
    {
        [HttpGet("Média")]
        public string Media(double numeroNota1, double numeroNota2, int numeroMatricula)
        {
            double nota1, nota2, media;
            int matricula;
            nota1 = numeroNota1;
            nota2 = numeroNota2;
            matricula = numeroMatricula;
            media = (nota1 + nota2) / 2;

            if (media > 7)
            {
                return($"Matrícula: {matricula},Média:{media} e o aluno aprovado!");
            }
            else if (media < 7)
            {
                return ($"Matrícula: {matricula},Média:{media} e o aluno reprovado!");
            }
            else if (media == 7)
            {
                return ($"Matrícula: {matricula},Média:{media} e o aluno em recuperação!");
            }
            return null;
        }
    }
}
