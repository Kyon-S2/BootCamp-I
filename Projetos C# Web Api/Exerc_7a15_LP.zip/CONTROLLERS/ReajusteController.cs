﻿using Microsoft.AspNetCore.Mvc;
using System.Reflection.Metadata.Ecma335;

namespace $safeprojectname$.Controllers
{
    public class ReajusteController : Controller
    {
        [HttpGet("Reajuste")]
        public string Reajuste(double salario, string profissao)
        {
            double resultado;

            if (profissao == "TÉCNICO" || profissao == "técnico" || profissao == "TECNICO" || profissao == "tecnico" ||
                profissao == "Técnico" || profissao == "Tecnico")
            {

                resultado = salario + (salario * 15 / 100);

            }
            else if (profissao == "GERENTE" || profissao == "gerente" || profissao == "Gerente")
            {

                resultado = salario + (salario * 13 / 100);

            }
            else

                resultado = salario + (salario * 11 / 100);

            return ($"Sua profisssão é: {profissao}. Seu salário atual é: {salario}. Seu salário com reajuste é: {resultado}");
            
        }
        
    }
}
