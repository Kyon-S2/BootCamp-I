﻿using Microsoft.AspNetCore.Mvc;

namespace $safeprojectname$.Controllers
{
    public class TresNumerosController : Controller
    {
        [HttpGet("TresNumeros")]
        public string TresNumeros(double numeroUsuario1, double numeroUsuario2, double numeroUsuario3)
        {
            double numero1, numero2, numero3;

            numero1 = (double)numeroUsuario1;
            numero2 = (double)numeroUsuario2;
            numero3 = (double)numeroUsuario3;



            if (numero1 > numero2 && numero1 > numero3)
            {
                return($"O número 1:{numero1} é maior");
            }
            else if (numero2 > numero1 && numero2 > numero3)
            {
                return($"O número 2: {numero2} é maior");

            }
            else if (numero3 > numero1 && numero3 > numero2)
            {
                return($"O número 3: {numero3} é maior!");

            }
            else if (numero1 == numero2 && numero1 > numero3)
            {
                return($"Os números 1 e 2: {numero1} são iguais e maiores!");

            }
            else if (numero1 == numero2 && numero1 < numero3)
            {
                return($"O número 3: {numero3} é maior!");

            }
            else if (numero3 == numero2 && numero1 > numero3)
            {
                return($"O número 1: {numero1} é maior!");

            }
            else if (numero3 == numero2 && numero1 < numero3)
            {
                return($"Os números 3 e 2: {numero3} são iguais e maiores!");

            }
            else if (numero1 == numero3 && numero1 > numero2)
            {
                return($"Os números 1 e 3: {numero1} são iguais e maiores!");

            }
            else if (numero1 == numero3 && numero1 < numero2)
            {
                return($"O número 2: {numero2} é maior");

            }
            else if (numero1 == numero2 && numero2 == numero3)
            {
                return($"Todos os números são iguais: {numero1}!");

            }

            return null;

        }
    }
}
