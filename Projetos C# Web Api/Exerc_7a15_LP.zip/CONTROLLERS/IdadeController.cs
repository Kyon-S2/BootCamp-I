﻿using Microsoft.AspNetCore.Mvc;

namespace $safeprojectname$.Controllers
{
    public class IdadeController : Controller
    {
        [HttpGet("Idade")]
        public string Idade(Int32 numeroUsuario)
        {

            int idade;
            idade = numeroUsuario;


            if (5 <= idade && idade <= 7)
            {
                return($"O nadador é da classe Infantil A e sua idade é: {idade}");
            }
            else if (8 <= idade && idade <= 11)
            {
                return($"O nadador é da classe Infantil B e sua idade é: {idade}");
            }
            else if (12 <= idade && idade <= 13)
            {
                return ($"O nadador é da classe Juvenil A e sua idade é: {idade}");
            }
            else if (14 <= idade && idade <= 17)
            {
                return ($"O nadador é da classe Juvenil B e sua idade é: {idade}");
            }
            else if (idade >= 18)
            {
                return ($"O nadador é da classe Adulto e sua idade é: {idade}");
            }
            else 
            {
                return($"Essa idade não está cadastrada!");
            }
            return null;
        }
    }
}
