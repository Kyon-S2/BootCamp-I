﻿using Microsoft.AspNetCore.Mvc;

namespace $safeprojectname$.Controllers
{
    public class CamisetaController : Controller
    {
        [HttpGet("Camiseta")]
        public string Camiseta(int codigoCamiseta, double valorCamiseta, string tamanhoCamiseta)
        {
            double resultado;
            

            if (tamanhoCamiseta == "G")
            {
                resultado = valorCamiseta - (valorCamiseta * 10 / 100);
                return ($"Código: {codigoCamiseta} | Tamanho: {tamanhoCamiseta} | Valor sem desconto {valorCamiseta} | Valor com Desconto {resultado}");
            }
            else if (tamanhoCamiseta == "M")
            {
                resultado = valorCamiseta - (valorCamiseta * 20 / 100);
                return ($"Código: {codigoCamiseta} | Tamanho: {tamanhoCamiseta} | Valor sem desconto {valorCamiseta} | Valor com Desconto {resultado}");
            }
            else if (tamanhoCamiseta == "P")
            {
                resultado = valorCamiseta - (valorCamiseta * 30 / 100);
                return ($"Código: {codigoCamiseta} | Tamanho: {tamanhoCamiseta} | Valor sem desconto {valorCamiseta} | Valor com Desconto {resultado}");
            }
            return null;
        }
    }
}
