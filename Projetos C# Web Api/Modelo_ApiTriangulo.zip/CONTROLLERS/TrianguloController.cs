﻿using Microsoft.AspNetCore.Mvc;
using System.Reflection.Metadata.Ecma335;

namespace $safeprojectname$.Controllers
{
    public class TrianguloController : Controller
    {
        [HttpGet("Triangulo")]
        public string trinangulo(double numeroUsuario1, double numeroUsuario2, double numeroUsuario3)
        {

            double lado1, lado2, lado3;
            lado1 = numeroUsuario1;
            lado2 = numeroUsuario2;
            lado3 = numeroUsuario3;

            if ((lado1 + lado2 > lado3) && (lado1 + lado3 > lado2) && (lado2 + lado3 > lado1))
            {
                if ((lado1 == lado2) && (lado1 == lado3))

                {
                    return("Os lados formam um triângulo equilátero");
                }
                else if ((lado1 == lado2) || (lado2 == lado3) || (lado1 == lado3))
                {
                    return("Os lados formam um triângulo isóceles");
                }
                else
                {
                    return ("Os lados formam um triângulo escaleno");
                }
            }

            else
            {
                return("Esse números não formam um triângulo");
            }
            return null;
        }

        
    }
}
