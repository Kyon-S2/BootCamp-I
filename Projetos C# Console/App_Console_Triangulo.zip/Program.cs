﻿using System.ComponentModel.Design;

double lado1, lado2, lado3;

Console.WriteLine("Informe o primeiro lado do triângulo");
lado1 = Convert.ToDouble(Console.ReadLine());
Console.WriteLine("Informe o segundo lado do triângulo");
lado2 = Convert.ToDouble(Console.ReadLine());
Console.WriteLine("Informe o terceiro lado do triângulo");
lado3 = Convert.ToDouble(Console.ReadLine());

if ((lado1 + lado2 > lado3) && (lado1 + lado3 > lado2) && (lado2 + lado3 > lado1))
{
    if ((lado1 == lado2) && (lado1 == lado3))

    {
        Console.WriteLine("Os lados formam um triângulo equilátero");
    }
    else if ((lado1 == lado2) || (lado2 == lado3) || (lado1 == lado3))
    {
        Console.WriteLine("Os lados formam um triângulo isóceles");
    }
    else
    {
        Console.WriteLine("Os lados formam um triângulo escaleno");
    }
}

else
{
    Console.WriteLine("Esse números não formam um triângulo");
}
